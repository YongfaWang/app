License and legal
=================

.. include:: ../LICENSE
