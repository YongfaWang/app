.. LISA Constants documentation master file, created by
   sphinx-quickstart on Fri Dec 17 22:05:50 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

LISA Constants
==============

LISA Constants is a Python package providing values sanctioned by the LISA
Consortium for physical constants and mission parameters. LISA Constants is
intended to be consistently used by other pieces of software related to the
simulation of the instrument, of gravitational wave signals, and others.

We provide support for Python projects (as a package), C projects (as a header
file), and C++ projects (as a header file). See below how to use the package.

.. toctree::
   :maxdepth: 1
   :caption: Getting started

   quickstart
   list

.. toctree::
   :maxdepth: 1
   :caption: Reference

   constant

.. toctree::
   :maxdepth: 1
   :caption: Others

   Gitlab project page <https://gitlab.in2p3.fr/lisa-simulation/constants>
   legal
