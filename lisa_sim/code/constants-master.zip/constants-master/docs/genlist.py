#! /usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Generate list of constants to be used by Sphinx.

This module uses the template 'list.template' to return a markdown file,
which can be piped into 'list.md' and used by Sphinx to generate documentation.

Authors:
    Jean-Baptiste Bayle <j2b.bayle@gmail.com>
"""
# pylint: disable=no-name-in-module

from jinja2 import Template
from jinja2.filters import FILTERS, pass_environment

from lisaconstants import __version__
from lisaconstants.constants import Constant


@pass_environment
def snake2title(_, snake):
    """Convert snake-case to title capitalization."""
    words = [word.capitalize() for word in snake.split("_")]
    return " ".join(words)


FILTERS["snake2title"] = snake2title


def markdown_list():
    """Return a markdown list of all constants."""
    # Read the template
    with open("list.template", "r", encoding="utf-8") as mdfile:
        content = mdfile.read()
    template = Template(content, trim_blocks=True)

    # Give an alphabetically ordered list of constants
    constants = set(Constant.ALL.values())
    constants = sorted(constants, key=lambda x: x.names[0])

    print(
        template.render(
            version=__version__,
            constants=constants,
        )
    )


if __name__ == "__main__":
    markdown_list()
