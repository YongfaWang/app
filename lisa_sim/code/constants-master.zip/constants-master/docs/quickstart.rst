Quickstart
==========

Installation
------------

Install the latest stable version from `PyPI
<https://pypi.org/project/lisaconstants/>`_ using pip,

.. code-block:: shell

  pip install lisaconstants

We recommend that you use virtual environments to isolate your project's
dependencies and avoid version conflicts. You can create a virtual environment
using Python's built-in `venv <https://docs.python.org/3/library/venv.html>`_
module, using `virtualenv <https://virtualenv.pypa.io>`_, or using a tool like
`conda <https://docs.conda.io>`_.

If needed, you can also specify the version you want to install.

.. code-block:: shell

  pip install lisaconstants==<version>


Usage
-----

With Python
~~~~~~~~~~~

Bare pyproject.toml
'''''''''''''''''''

If you are using a bare pyproject.toml file in your Python project, add LISA
Constants as a dependency,

.. code-block:: toml

  [project]
  name = "mypackage"
  # ...
  dependencies = [
    "lisaconstants == 1.3.4",
  ]

We recommend that you specify the version of LISA Constants you are using in
your project. This will ensure that your project will continue to work even if
the LISA Constants API changes in the future.

With a packaging and dependency management tool
'''''''''''''''''''''''''''''''''''''''''''''''

If you are using a packaging and dependency management tool, such as `Poetry
<https://python-poetry.org>`_, follow the instructions to declare the
LISA Constants as a dependency. For Poetry, run the following command:

.. code-block:: shell

  poetry add lisaconstants==1.3.4

With setup.py (legacy)
''''''''''''''''''''''

If you are using the legacy setup.py file, follow a similar procedure,

.. code-block:: python

  setup(
    name='mypackage',
    # ...
    install_requires=[
      'lisaconstants'
    ],
  )

Note that using setup.py is discouraged in favor of pyproject.toml or modern
packaging tools like Poetry. For more information, see `Packaging Python
Projects <https://packaging.python.org/tutorials/packaging-projects/>`_.

Usage
'''''

Now you can use the constants in your project,

.. code-block:: python

  from lisaconstants import c

  light_minute = 60 * c
  travel_time = 2.5E8 / c

For the list of available quantities, see :doc:`list`.

Silence static linter warnings
''''''''''''''''''''''''''''''

LISA Constants dynamically generates the constants when the module is imported.
Static code analyzers, such as `pylint <https://www.pylint.org>`_, do
not import the module and therefore incorrectly issue warnings for each constant
imported from LISA Constants.

To silence these warnings, edit your project's pyproject.toml file and add the
following configuration,

.. code-block:: toml

  [tool.pylint.TYPECHECK]
  ignored-modules = "lisaconstants"


Alternatively, create a file ".pylintrc" if it does not exist, and add the
following commands,

.. code-block:: ini

  [TYPECHECK]

  ignored-modules=lisaconstants

Using with C or C++
~~~~~~~~~~~~~~~~~~~

Header generation
'''''''''''''''''

Use the provided Python script to generate a header file with the LISA Constants
whenever you need to use them in a C or C++ project.

.. code-block:: shell

  python -m lisaconstants --dir destination/directory c

We recommend that you automatically re-generate the header file whenever your
compile your project, taking advantage of building tools, such as Make.

Add the following command to your Makefile,

.. code-block:: make

  lisaconstants.h:
      python -m lisaconstants --dir . c

  my_project: lisaconstants.h
      gcc -o my_project my_project.c


Usage with C
''''''''''''

Include lisaconstants.h. Constants are prefixed with `LISA_` to prevent name
collisions.

.. code-block:: c

  #include "lisaconstants.h"

  double light_minute = 60 * LISA_c;
  double travel_time = 2.5E8 / LISA_c;

Usage with C++
'''''''''''''''

Include lisaconstants.hpp. Constants are defined in the `LisaConstants`
namespace to prevent name collisions.

.. code-block:: cpp

  #include "lisaconstants.h"

  double light_minute = 60 * LisaConstants::c;
  double travel_time = 2.5E8 / LisaConstants::c;
