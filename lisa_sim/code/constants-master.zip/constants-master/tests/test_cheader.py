#! /usr/bin/env python3
# -*- coding: utf-8 -*-
"""Test C/C++ header generation."""

import os
import tempfile

from pytest import fixture

from lisaconstants.constants import Constant
from lisaconstants.headers import CHeaderGenerator, CppHeaderGenerator


@fixture(name="constants")
def h2g2() -> dict[str, Constant]:
    """Return dictionary of H2G2 constants."""

    Constant("LIFE_UNIVERSE", 42, None, "Answer to life, the Universe and everything")
    Constant("TEAPOT", "418", None, "I am a teapot")
    Constant.alias("l", "LIFE_UNIVERSE")

    return Constant.ALL


def word_in_file(word: str, filename: str) -> bool:
    """Check that a word can be found in file.

    Args:
        word: word to find
        filename: path to file
    """
    with open(filename, "r", encoding="utf-8") as file:
        return any(word in line for line in file)


def test_cpp(constants: dict[str, Constant]) -> None:
    """Test generation of C++ header."""

    with tempfile.TemporaryDirectory() as temp_dir:

        filename = os.path.join(temp_dir, "lisaconstants.hpp")
        CppHeaderGenerator(constants).write(filename)

        assert os.path.exists(filename)
        assert word_in_file("LIFE_UNIVERSE", filename)
        assert word_in_file("TEAPOT", filename)
        assert word_in_file("l", filename)


def test_c(constants: dict[str, Constant]) -> None:
    """Test generation of C header."""

    with tempfile.TemporaryDirectory() as temp_dir:

        filename = os.path.join(temp_dir, "lisaconstants.h")
        CHeaderGenerator(constants).write(filename)

        assert os.path.exists(filename)
        assert word_in_file("LISA_LIFE_UNIVERSE", filename)
        assert word_in_file("LISA_TEAPOT", filename)
