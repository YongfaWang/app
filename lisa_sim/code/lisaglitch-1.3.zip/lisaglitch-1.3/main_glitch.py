#! /usr/bin/env python3
# -*- coding: utf-8 -*-
#
# BSD 3-Clause License
#
# Copyright 2022, by the California Institute of Technology.
# ALL RIGHTS RESERVED. United States Government Sponsorship acknowledged.
# Any commercial use must be negotiated with the Office of Technology Transfer
# at the California Institute of Technology.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this
#    list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
#
# 3. Neither the name of the copyright holder nor the names of its
#    contributors may be used to endorse or promote products derived from
#    this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# This software may be subject to U.S. export control laws. By accepting this
# software, the user agrees to comply with all applicable U.S. export laws and
# regulations. User has the responsibility to obtain export licenses, or other
# export authority as may be required before exporting such information to
# foreign countries or providing access to foreign persons.
#
"""
Generate figures for various glitch types.

This script is used by Gitlab-CI to generate example figures.

Authors:
    Jean-Baptiste Bayle <j2b.bayle@gmail.com>
"""

import logging
import argparse
import lisaglitch
import h5py


def main():
    """Main function."""
    """Generate a step glitch."""
    dataSize = 8000
    time_t0 = 2032084800.0
    time_inj = time_t0 + 1000

    """Generate a rectangle glitch."""
    for inj in lisaglitch.INJECTION_POINTS:
        glitch = lisaglitch.RectangleGlitch(inj_point=inj, width=2, size=dataSize, t0=time_t0, t_inj=time_inj)
        # glitch.plot(inj+'.pdf')
        glitch.write('../data/RectangleGlitch.h5', 'a')
    return 0

    for inj in lisaglitch.INJECTION_POINTS:
        glitch = lisaglitch.StepGlitch(inj_point=inj, size=dataSize, t0=time_t0, t_inj=time_inj)
        # glitch.plot(inj+'.pdf')
        # print(inj)
        glitch.write('../data/stepGlitch.h5', 'a')

    """Generate a shapelet glitch."""
    for inj in lisaglitch.INJECTION_POINTS:
        glitch = lisaglitch.ShapeletGlitch(inj_point=inj, size=dataSize, t0=time_t0, t_inj=time_inj)
        glitch.write('../data/ShapeletGlitch.h5', 'a')

    """Generate an integrated shapelet glitch."""
    for inj in lisaglitch.INJECTION_POINTS:
        glitch = lisaglitch.IntegratedShapeletGlitch(inj_point=inj, size=dataSize, t0=time_t0, t_inj=time_inj)
        glitch.write('../data/IntegratedShapeletGlitch.h5', 'a')
    """Generate a one-sided double-exponential glitch."""
    for inj in lisaglitch.INJECTION_POINTS:
        glitch = lisaglitch.OneSidedDoubleExpGlitch(inj_point=inj, t_rise=1, t_fall=2,size=dataSize, t0=time_t0, t_inj=time_inj)
        # glitch.plot(inj+'.pdf')
        glitch.write('../data/OneSidedDoubleExpGlitch.h5', 'a')

    """Generate an integrated one-sided double-exponential glitch."""
    for inj in lisaglitch.INJECTION_POINTS:
        glitch = lisaglitch.IntegratedOneSidedDoubleExpGlitch(inj_point=inj, t_rise=1, t_fall=2,size=dataSize, t0=time_t0, t_inj=time_inj)
        # glitch.plot(inj+'.pdf')
        glitch.write('../data/IntegratedOneSidedDoubleExpGlitch.h5', 'a')

    """Generate a two-sided double-exponential glitch."""
    for inj in lisaglitch.INJECTION_POINTS:
        glitch = lisaglitch.TwoSidedDoubleExpGlitch(inj_point=inj, t_rise=1, t_fall=2, displacement=10,size=dataSize, t0=time_t0, t_inj=time_inj)
        # glitch.plot(inj+'.pdf')
        glitch.write('../data/TwoSidedDoubleExpGlitch.h5', 'a')

    """Generate an integrated two-sided double-exponential glitch."""
    for inj in lisaglitch.INJECTION_POINTS:
        glitch = lisaglitch.IntegratedTwoSidedDoubleExpGlitch(inj_point=inj, t_rise=1, t_fall=2, displacement=10,size=dataSize, t0=time_t0, t_inj=time_inj)
        # glitch.plot(inj+'.pdf')
        glitch.write('../data/IntegratedTwoSidedDoubleExpGlitch.h5', 'a')


if __name__ == '__main__':
    main()

    # glitch = lisaglitch.HDF5Glitch(path='stepGlitch.h5', inj_point='tm_12')
    # glitch.plot('test.pdf')

    #with h5py.File('stepGlitch.h5', 'r') as f:
    #    print('DataSet in file:')
    #    print(list(f.keys()))
    #    data = f['tm_12'][:]
    #    print("Data in 'dataset_name':")
    #    print(data)
