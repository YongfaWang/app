<template>
  <t-layout>
    <t-header>
      <t-row>
        <t-col>
          <t-button @click="back" shape="rectangle" variant="outline">
            打开文件
          </t-button>
        </t-col>
        <t-col>
        </t-col>
      </t-row>
    </t-header>
    <t-list :split="true" style="max-height: 300px" stripe>
      <t-list-item>
        测试内容测试内容1
        <template #action>
          <span>
            <t-link theme="primary" hover="color" style="margin-left: 16px">绘图</t-link>
          </span>
        </template>
      </t-list-item>
      <t-list-item>
        测试内容测试内容2
        <template #action>
          <span>
            <t-link theme="primary" hover="color" style="margin-left: 16px">绘图</t-link>
          </span>
        </template>
      </t-list-item>
      <t-list-item>
        测试内容测试内容3
        <template #action>
          <span>
            <t-link theme="primary" hover="color" style="margin-left: 16px">绘图</t-link>
          </span>
        </template>
      </t-list-item>
      <t-list-item>
        测试内容测试内容4
        <template #action>
          <span>
            <t-link theme="primary" hover="color" style="margin-left: 16px">绘图</t-link>
          </span>
        </template>
      </t-list-item>
      <t-list-item>
        测试内容测试内容5
        <template #action>
          <span>
            <t-link theme="primary" hover="color" style="margin-left: 16px">绘图</t-link>
          </span>
        </template>
      </t-list-item>
      <t-list-item>
        测试内容测试内容5
        <template #action>
          <span>
            <t-link theme="primary" hover="color" style="margin-left: 16px">绘图</t-link>
          </span>
        </template>
      </t-list-item>
    </t-list>
  </t-layout>
</template>
<script>

export default {
  name: 'H5View',
  components: {
  },
  created() {
  },
  data() {
    return {
    }
  },
  methods: {

  }
}
</script>
<style></style>