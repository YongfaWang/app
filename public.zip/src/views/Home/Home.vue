<template>
  <div style="height: 100%; width: 100%; min-width: 900px; min-height: 300px;">
    <div style="position: relative; top: calc((7vh + 2vh + 7vh + 7vh +1.5vh));">
      <t-row justify="center" :gutter="[
        { xs: 8, sm: 16, md: 24, lg: 32, xl: 32, xxl: 40 },
        { xs: 8, sm: 16, md: 24, lg: 32, xl: 32, xxl: 40 },
      ]">
        <t-col>
          <div class="button-wh">
            <DesktopButton tooltip="点击后进行Orbits操作" content="Orbits"></DesktopButton>
          </div>
        </t-col>
        <t-col>
          <!-- <SwapRightIcon /> -->
          <svg xmlns="http://www.w3.org/2000/svg" width="7vh" height="7vh" style="min-width: 100px; min-height: 100px;"
            viewBox="0 0 24 24">
            <path fill="currentColor"
              d="M4.5 11h11.586l-4.5-4.5L13 5.086L19.914 12L13 18.914L11.586 17.5l4.5-4.5H4.5z" />
          </svg>
        </t-col>
        <t-col>
          <div class="button-wh">
            <DesktopButton tooltip="点击后进行GW Response操作" content="GW Response"></DesktopButton>
          </div>
        </t-col>
        <t-col>
          <!-- <SwapRightIcon /> -->
          <svg xmlns="http://www.w3.org/2000/svg" width="7vh" height="7vh" style="min-width: 100px; min-height: 100px;"
            viewBox="0 0 24 24">
            <path fill="currentColor"
              d="M4.5 11h11.586l-4.5-4.5L13 5.086L19.914 12L13 18.914L11.586 17.5l4.5-4.5H4.5z" />
          </svg>
        </t-col>
        <t-col>
          <div class="button-wh">
            <DesktopButton tooltip="点击后进行Instrument操作" content="Instrument"></DesktopButton>
          </div>
        </t-col>
        <t-col>
          <!-- <SwapRightIcon /> -->
          <svg xmlns="http://www.w3.org/2000/svg" width="7vh" height="7vh" style="min-width: 100px; min-height: 100px;"
            viewBox="0 0 24 24">
            <path fill="currentColor"
              d="M4.5 11h11.586l-4.5-4.5L13 5.086L19.914 12L13 18.914L11.586 17.5l4.5-4.5H4.5z" />
          </svg>
        </t-col>
        <t-col>
          <div class="button-wh">
            <DesktopButton tooltip="点击后进行H5 View操作" content="H5 View" @onClick="pageRouter('h5view')"></DesktopButton>
          </div>
        </t-col>
      </t-row>

      <t-row justify="center" style="margin-top: 2vh;" :gutter="[
        { xs: 8, sm: 16, md: 24, lg: 32, xl: 32, xxl: 40 },
        { xs: 8, sm: 16, md: 24, lg: 32, xl: 32, xxl: 40 },
      ]">
        <t-col>

          <div class="button-wh"></div>
        </t-col>
        <t-col>
          <!-- <SwapRightIcon /> -->
          <div class="button-wh"></div>
        </t-col>
        <t-col>
          <div class="button-wh">
          </div>
        </t-col>
        <t-col>
          <!-- <SwapRightIcon /> -->
          <div class="button-wh"></div>
        </t-col>
        <t-col>
          <div class="button-wh">
            <svg xmlns="http://www.w3.org/2000/svg" width="7vh" height="7vh"
              style="min-width: 100px; min-height: 100px;" viewBox="0 0 24 24">
              <path fill="currentColor"
                d="M11 19.5V7.914l-4.5 4.5L5.086 11L12 4.086L18.914 11L17.5 12.414l-4.5-4.5V19.5z" />
            </svg>
          </div>
        </t-col>
        <t-col>
          <!-- <SwapRightIcon /> -->
          <div class="button-wh"></div>
        </t-col>
        <t-col>
          <!-- <SwapRightIcon /> -->
          <div class="button-wh"></div>
        </t-col>
      </t-row>

      <t-row justify="center" :gutter="[
        { xs: 8, sm: 16, md: 24, lg: 32, xl: 32, xxl: 40 },
        { xs: 8, sm: 16, md: 24, lg: 32, xl: 32, xxl: 40 },
      ]">
        <t-col>

          <div class="button-wh"></div>
        </t-col>
        <t-col>
          <!-- <SwapRightIcon /> -->

          <div class="button-wh"></div>
        </t-col>
        <t-col>
          <div class="button-wh">
          </div>
        </t-col>
        <t-col>
          <!-- <SwapRightIcon /> -->
          <div class="button-wh"></div>
        </t-col>
        <t-col>
          <div class="button-wh">
            <div class="button-wh">
              <DesktopButton tooltip="点击后进行Glitchs操作" content="Glitchs"></DesktopButton>
            </div>
          </div>
        </t-col>
        <t-col>
          <!-- <SwapRightIcon /> -->
          <div class="button-wh"></div>
        </t-col>
        <t-col>
          <!-- <SwapRightIcon /> -->
          <div class="button-wh"></div>
        </t-col>
      </t-row>
    </div>
    <div>
      <t-dialog width="50%" placement="center" v-model:visible="winconfig.h5view.isShow" header="H5View" @confirm="applyH5view">
        <div>
          <H5View />
        </div>
      </t-dialog>
    </div>
  </div>
</template>

<script>
import DesktopButton from '@/components/desktopButton/desktopButton';
import H5View from '@/views/H5View/H5View';
// const router = useRouter();
// import { onMounted } from 'vue';
// onMounted(() => {
//   console.log("Home 页面加载");
// })
// function pageRouter(flag) {
//   if (flag == 'h5view') {
//     console.log(router);
//     router.push("/h5view?mykey=luckey");

//   }
// }
export default {
  name: 'Home-a',
  components: {
    DesktopButton,
    H5View
  },
  setup() {
  },
  created() {
    console.log("Home 页面加载");

  },
  data() {
    return {
      winconfig: {
        h5view: {
          isShow: false
        }
      }
    }
  },
  methods: {
    pageRouter(flag) {
      // this.$emit("itemClicked", flag)
      switch (flag) {
        case "h5view":
          this.showH5view();
          break;
        default:
          break;
      }
    },
    showH5view() {
      this.winconfig.h5view.isShow = true
    }
  }
}
</script>

<style>
.button-wh {
  width: 10vh;
  height: 10vh;
  min-width: 100px;
  min-height: 100px;
}
</style>
