const { defineConfig } = require('@vue/cli-service')
module.exports = defineConfig({
  transpileDependencies: true,
  pluginOptions: {
    electronBuilder: {
      nodeIntegration: true, // 关键！启用 Node.js 集成
    }
  }
})

// import { defineConfig } from '@vue/cli-service'
// export default defineConfig({
//   transpileDependencies: true,
//   pluginOptions: {
//     electronBuilder: {
//       nodeIntegration: true, // 关键！启用 Node.js 集成
//     }
//   }
// })